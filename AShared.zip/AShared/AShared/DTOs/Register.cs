﻿namespace AShared.DTOs
{
    public record Register(string Phone, string Email);
   
}
