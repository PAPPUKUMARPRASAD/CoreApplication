﻿using AShared.DTOs;

namespace AShared.Contracts
{
    public interface IAccountService
    {
        string RegisterUser(Register registerDetails);
    }
}
