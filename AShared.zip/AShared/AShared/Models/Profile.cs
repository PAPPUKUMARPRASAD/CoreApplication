﻿namespace AShared.Models;
public class Profile
{
    public string Phone { get; set; }

    public string Email { get; set; }

}
