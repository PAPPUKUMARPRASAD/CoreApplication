﻿using AShared.Models;

namespace AShared.Database
{
    public static class ProfileDatabase
    {
        private static List<Profile> _profile = new List<Profile>();

        public static void AddProfile(Profile profile)
        {
            try
            {
                _profile.Add(profile);
            }
            catch
            {
                throw;
            }
        }

        public static void RemoveProfile(Profile profile)
        {
            try
            {
                _profile.Remove(profile);
            }
            catch
            {
                throw;
            }
        }

        public static bool FindByEmail(string email)
        {
            return _profile.Any(x => x.Email == email);
        }
    }
}
