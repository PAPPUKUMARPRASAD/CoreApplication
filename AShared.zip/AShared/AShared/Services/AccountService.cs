﻿using AShared.Contracts;
using AShared.Database;
using AShared.DTOs;
using AShared.Models;


namespace AShared.Services;

public class AccountService : IAccountService
{
    public AccountService() { }

    public string RegisterUser(Register registerDetails)
    {
        if (IsEmailExist(registerDetails.Email))
        {
            return "Email already exist";
        }

        var profile = new Profile()
        {
            Email = registerDetails.Email,
            Phone = registerDetails.Phone,
        };
        ProfileDatabase.AddProfile(profile);
        return string.Empty;

    }

    private bool IsEmailExist(string email)
    {
        return ProfileDatabase.FindByEmail(email);
    }
}
