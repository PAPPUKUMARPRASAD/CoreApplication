﻿using AShared.Contracts;
using AShared.DTOs;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace AShared.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AccountController : ControllerBase
    {
        public AccountController(IAccountService accountService)
        {
            AccountService = accountService;
        }

        public IAccountService AccountService { get; }

        [HttpPost]
        [Route("Register")]
        public IActionResult Register(Register register)
        {
            var result = AccountService.RegisterUser(register);
            if (string.IsNullOrWhiteSpace(result))
            {
                return Created("https://localhost:2586/api/Get",register.Email);
            }
            return BadRequest(result);
        }
    }
}
